OTF and TTF: Wicked Mouse (Regular and 3D)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Hold onto your hats folks! Wicked Mouse is a playful display font that captures the magic of cartoons from a distant era. Basic latin, punctuation, extended latin, and diacritics are included in the full versions. Lowercase characters differ slightly in variation and rotation in the regular version while they 
mirror their uppercase counterparts in the 3D one. Do check the included glyph maps for all the characters. (slight overlap to be expected with some of the characters) Wacky, childlike, and loose in nature, you'll be able to inject a bit of fun with this typeface into a drab project. Use Wicked Mouse
for a children's book, web pages, or a fun logo design. Unleash your inner kid! A demo of the regular version is included for personal use. Full version plus 3D can be purchased for $15 or by purchasing a commercial license. 

Please note the $15 purchase is for PERSONAL use only and does NOT initiate a business contract.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: retro, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, kid, sans, san serif, TV, cartoon, cartoons, saturday, Disney, Mickey, character, like, poster, headline, Porky, animation, children, children's, kids, playful, wacky, fun, funny, comedy




